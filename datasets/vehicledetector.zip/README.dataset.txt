# Vehicle detector > 2023-07-25 4:22pm
https://universe.roboflow.com/simform/vehicle-detector-4qmcw

Provided by a Roboflow user
License: CC BY 4.0

