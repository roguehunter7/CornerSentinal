# Lorry and Auto > LorryandAutoFinal
https://universe.roboflow.com/major-project/lorry-and-auto

Provided by a Roboflow user
License: Public Domain

